select
	FileID as [Order.Number],
	ClosedDate as [Order.CloseDate],
	SourceOfBusiness as [Customer.Contact],
	SourceOfBusinessCompany as [Customer.Company]
from
	crm.Orders o
where
	FileID = 1649345 or FileID = 354938 for JSON PATH,
	ROOT('Orders')