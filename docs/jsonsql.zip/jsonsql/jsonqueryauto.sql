select
	FileID,
	ClosedDate,
	SourceOfBusiness,
	SourceOfBusinessCompany
from
	crm.Orders o
where
	FileID = 1649345 or FileID = 354938 for JSON AUTO, INCLUDE_NULL_VALUES